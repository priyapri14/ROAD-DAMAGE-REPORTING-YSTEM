from django.shortcuts import render
from django.contrib.auth.decorators import login_required
from django.contrib.auth.models import User

@login_required(login_url='signin')
def home(request):
    return render(request, 'home.html')

def location(request):
    return render(request,'location.html')

def location2(request):
    return render(request,'location2.html')


def location3(request):
    return render(request,'location3.html')

def thankyou(request):
    return render(request, 'thankyou.html')