from django.urls import path
from .views import signin, signup, signout,location,location2,location3,contact,contact_page,thankyou

urlpatterns = [
    path('signin/'  , signin, name='signin'),
    path('signup/'  , signup, name='signup'),
    path('logout/'  , signout, name='signout'),
    path('logout/'  , signout, name='signout'),
    path('location/',location,name='location'), 
    path('location2/',location2,name='location2'),
    path('contact/',contact,name='contact'), 
    path('contact_page', contact_page, name='contact_page'),
    path('location3/',location3,name='location3'),
    path('thankyou/', thankyou ,name='thankyou'), 
]
