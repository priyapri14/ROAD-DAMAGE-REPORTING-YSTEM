from django.db import models
from location_field.models.plain import PlainLocationField

# Create your models here.
class LoginForm(models.Model):
    username = models.CharField(max_length=30)
    password = models.CharField(max_length=30)
    def __str__(self):
        return self.username

class RegistrationForm(models.Model):
    firstname = models.CharField(max_length=30)
    lastname = models.CharField(max_length=20)
    email = models.CharField(max_length=30)
    username = models.CharField(max_length=30)
    password = models.CharField(max_length=30)
    confirm_password = models.CharField(max_length=30)
    def __str__(self):
        return self.firstname

class location(models.Model):
    state=models.CharField(max_length=20)
    district=models.CharField(max_length=20)
    area = models.CharField(max_length=30)
    landmark = models.CharField(max_length=20)
    text=models.CharField(max_length=30)
    def __str__(self):
        return self.state

class location2(models.Model):
    upload_evidence = models.ImageField(null=True, blank=True)
    text=models.CharField(max_length=30)

    

class location3(models.Model):
    location = PlainLocationField(based_fields=['city'], zoom=7)
    text=models.CharField(max_length=30)
    def __str__(self):
        return self.location



class contact_page(models.Model):
    name= models.CharField(max_length=20)
    email = models.CharField(max_length=30)
    content=models.CharField(max_length=70)
    
    

    
