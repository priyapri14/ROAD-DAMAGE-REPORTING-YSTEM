from django.apps import AppConfig


class AuthappConfig(AppConfig):
    name = 'authapp'
