from django.shortcuts import render, redirect
from django.contrib.auth.models import User
from django.contrib.auth import authenticate, login, logout
from django.http import HttpResponse
from .forms import LoginForm, RegistrationForm     
from .forms import locationForm 
from .forms import ContactForm



def signin(request):
    forms = LoginForm()
    if request.method == 'POST':
        forms = LoginForm(request.POST)
        if forms.is_valid():
            username = forms.cleaned_data['username']
            password = forms.cleaned_data['password']
            user = authenticate(username=username, password=password)
            if user:
                login(request, user)
                print("welcome" )
                return redirect('home')
    context = {
        'form': forms
    }
    print("please enter correct username and pasword!!!")
    return render(request, 'signin.html', context)


def signup(request):
    forms = RegistrationForm()
    if request.method == 'POST':
        forms = RegistrationForm(request.POST)
        if forms.is_valid():
            firstname = forms.cleaned_data['firstname']
            lastname = forms.cleaned_data['lastname']
            email = forms.cleaned_data['email']
            username = forms.cleaned_data['username']
            password = forms.cleaned_data['password']
            confirm_password = forms.cleaned_data['confirm_password']
            if password == confirm_password:
                try:
                    User.objects.create_user(username=username, password=password, email=email, first_name=firstname, last_name=lastname)
                    print("REGISTRATION IS SUCCESSFULL!!!!")
                    return redirect('signin')
                except:
                    context = {
                        'form': forms,
                        'error': 'This Username Already exists!'
                    }
                    return render(request, 'signup.html', context)
    context = {
        'form': forms
    }
    return render(request, 'signup.html', context)

def signout(request):
    logout(request)
    print(" Logout is successfull!!!, THANKYOU!!!")
    return redirect('signin')


def location(request):
    if request.method == "POST":
        print(request.POST)
        print("success!")
    else:
        print("it's wrong")
        

    return render(request,'location.html',context)



def location2(request):
    location2= ContactForm(request.POST or None)
    
    if request.method == "POST":
        print(request.POST)
        print(request.POST.get('upload_evidance'))
        print(request.POST.get('text'))
        print("EVIDENCE UPLOADED SUCCESSFULLY")
    return render(request,'location2.html')
  
def contact(request):
    return render(request, 'contact.html')


def contact_page(request):
    contact_form= ContactForm(request.POST or None)
    context = {
        "title" : "CONTACT:",
        "form"  : contact_form
    }
    if contact_form.is_valid():
        print(contact_form.cleaned_data)

    if request.method =="POST":
        print(request.POST)
        print(request.POST.get('fullname'))
        print(request.POST.get('email'))
        print(request.POST.get('context'))
    return render(request,"contact/view.html", context)  


def location3(request):
    return render(request,'location3.html')


def thankyou(request):
    return render(request,'thankyou.html')

  