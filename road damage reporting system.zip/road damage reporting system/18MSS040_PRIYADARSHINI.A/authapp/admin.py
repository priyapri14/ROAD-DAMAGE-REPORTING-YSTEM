from django.contrib import admin

# Register your models here.
from.models import LoginForm
from.models import RegistrationForm
from.models import location
from.models import location2
from.models import location3
from.models import contact_page



admin.site.register(LoginForm)
admin.site.register(RegistrationForm)
admin.site.register(location)
admin.site.register(location2)
admin.site.register(location3)
admin.site.register(contact_page)
